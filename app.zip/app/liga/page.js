export default function Liga() {
    return <h1 className="text-2xl font-semibold">Strona Ligi</h1>;
  }
  