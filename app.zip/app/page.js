export default function Home() {
  return (
    <div>
      <h1 className="text-2xl font-semibold">Witaj na stronie Rummikub!</h1>
      <p className="mt-2">Wybierz opcję z menu, aby przejść dalej.</p>
    </div>
  );
}
