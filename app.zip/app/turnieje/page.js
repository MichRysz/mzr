export default function Turnieje() {
    return <h1 className="text-2xl font-semibold">Strona Turniejów</h1>;
  }
  