export default function Regulamin() {
    return <h1 className="text-2xl font-semibold">Regulamin</h1>;
  }
  